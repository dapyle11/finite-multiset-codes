# Revision history

## Integrated expanded edition — 18 October 2026

Replaces the earlier standalone ternary note as the single current manuscript. The earlier source and PDF remain separately preserved as a private baseline backup.

Added the arbitrary-cap reduction, exact arbitrary-alphabet cone, all-alphabet infinite full-coset separation and q^2 classification; recast the complete ternary cone as a corollary with its full-lattice construction; added the next-band eight-word theorem, equality rigidity and 8-versus-7 family; added the finite four-coordinate 6-versus-5 certificate and boundary counterexamples; added exact quinary length-nine and length-ten cases and length-ten equality conditions.

Included independent checks, exact certificates, reproducibility commands, explicit integer parameter domains, and startup protection for legacy assertion-based verification. Retained the contribution disclosure, license status, non-publication status, and unresolved 2024 full-text comparison. No priority, peer-review, or AI-superiority claim was added.
