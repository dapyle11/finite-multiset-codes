# License status

No software or manuscript license has been selected. This package does not grant a license or make a legal copyright-ownership claim. Daniel should decide the intended reuse terms before public release and consider the treatment of AI-generated material and third-party references. No third-party paper PDFs are redistributed in this package.
