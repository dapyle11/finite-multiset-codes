"""Negative controls: each deliberately invalid certificate must be rejected."""
import copy,gzip,json,tempfile
from pathlib import Path
import independent_check as c
original=c.P
out=[]
with tempfile.TemporaryDirectory() as tmp:
 c.P=Path(tmp)
 with gzip.open(original/'exact_tree_n6.json.gz','rt') as f:tree=json.load(f)
 cases=[]
 for name,value in [('zero denominator',0),('negative denominator',-10000000),('noninteger denominator',10000000.0)]:
  t=copy.deepcopy(tree);t['denominator']=value;cases.append((name,t))
 t=copy.deepcopy(tree);t['nodes'][0]['exclude']=t['nodes'][0]['include'];cases.append(('repeated subtree',t))
 t=copy.deepcopy(tree);t['nodes'].append({'trivial':True});cases.append(('unreachable node',t))
 t=copy.deepcopy(tree)
 for node in t['nodes']:
  if 'dual' in node:node['dual']=[];break
 cases.append(('missing leaf coverage',t))
 for name,t in cases:
  with gzip.open(c.P/'exact_tree_n6.json.gz','wt') as f:json.dump(t,f)
  try:c.tree_check()
  except ValueError as e:out.append({'mutation':name,'rejected':str(e)})
  else:raise RuntimeError('accepted '+name)
 d=json.loads((original/'orbit_slices_n10_k6.json').read_text());d['weights'][0]['weight']='0'
 (c.P/'bad.json').write_text(json.dumps(d))
 try:c.orbit_check('bad.json',10,{3:7,6:42})
 except ValueError as e:out.append({'mutation':'deleted orbit weight','rejected':str(e)})
 else:raise RuntimeError('accepted deleted orbit')
c.P=original
(c.OUT/'mutation_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
