"""Independent certificate audit: Python standard library, no solver imports.
Enumerates vertices by separator positions, derives graph by direct L1 distance,
and determines all certificate supports through geometric membership predicates.
"""
import gzip,json,math,hashlib
from pathlib import Path
from itertools import combinations, permutations
from fractions import Fraction
P=Path(__file__).resolve().parents[1]/'q5'
OUT=Path(__file__).resolve().parent

def require(ok,msg):
 if not ok: raise ValueError(msg)
def integer(x): return type(x) is int

def vertices(n):
 require(integer(n) and n>=0,'bad weight')
 ans=[]
 for bars in combinations(range(n+4),4):
  cuts=(-1,)+bars+(n+4,)
  ans.append(tuple(cuts[i+1]-cuts[i]-1 for i in range(5)))
 ans.sort()
 require(len(ans)==math.comb(n+4,4) and len(set(ans))==len(ans),'enumeration')
 return ans

def l1(x,y): return sum(abs(a-b) for a,b in zip(x,y))
def clique_support(V,base,side):
 # Sum differences is one, hence the coordinatewise relation selects base +/- e_i.
 if side==-1: return frozenset(i for i,x in enumerate(V) if all(a>=b for a,b in zip(x,base)))
 return frozenset(i for i,x in enumerate(V) if all(a<=b for a,b in zip(x,base)))

def orbit_check(file,n,known):
 d=json.loads((P/file).read_text()); require(d['n']==n,'wrong n')
 V=vertices(n); coverage=[Fraction(0) for _ in V]; cost=Fraction(0);expanded=0; kinds={}
 for row in d['weights']:
  kind=row.get('kind','clique'); p=row.get('parameter',row.get('side')); base=row['type']; w=Fraction(row['weight'])
  require(len(base)==5 and all(integer(x) and x>=0 for x in base),'invalid base')
  require(integer(p) and w>=0,'invalid parameter/weight')
  bases=set(permutations(base));require(integer(row['count']) and len(bases)==row['count'],'orbit count')
  if kind=='clique':
   require(p in (-1,1) and sum(base)==n+p,'invalid clique base');rhs=1
  else:
   require(kind=='simplex' and p in known and sum(base)==n-p,'invalid simplex');rhs=known[p]
  require(row.get('rhs',rhs)==rhs,'invalid rhs')
  for b in bases:
   if kind=='clique':
    supp=clique_support(V,b,p)
    require(all(l1(V[i],V[j])==2 for i,j in combinations(supp,2)),'not a clique')
   else:
    supp=frozenset(i for i,x in enumerate(V) if all(a>=v for a,v in zip(x,b)))
    translated={tuple(a-v for a,v in zip(V[i],b)) for i in supp}
    require(translated==set(vertices(p)),'not a full translated simplex')
   for i in supp:coverage[i]+=w
   cost+=rhs*w;expanded+=1
  kinds[kind]=kinds.get(kind,0)+1
 require(all(c>=1 for c in coverage),'uncovered vertex');require(cost==Fraction(d['bound']),'wrong bound')
 return {'n':n,'vertices':len(V),'orbits':len(d['weights']),'kinds':kinds,'expanded_constraints':expanded,'min_coverage':str(min(coverage)),'max_coverage':str(max(coverage)),'cost':str(cost),'upper':cost.numerator//cost.denominator}

def tree_check():
 with gzip.open(P/'exact_tree_n6.json.gz','rt') as f:d=json.load(f)
 require(d['n']==6 and d['target']==43,'wrong tree problem')
 D=d['denominator'];require(integer(D) and D>0,'denominator must be positive integer')
 nodes=d['nodes'];V=vertices(6)
 adjacency=[set() for _ in V]
 for i,j in combinations(range(len(V)),2):
  if l1(V[i],V[j])==2:adjacency[i].add(j);adjacency[j].add(i)
 C=[]
 for s in (-1,1):
  for b in vertices(6+s):
   supp=clique_support(V,b,s)
   if len(supp)>1:
    require(all(j in adjacency[i] for i,j in combinations(supp,2)),'bad clique')
    C.append(supp)
 # Explicitly ensure these cliques cover precisely the direct-metric conflict graph.
 edges={tuple(sorted((i,j))) for c in C for i,j in combinations(c,2)}
 require(edges=={(i,j) for i in range(len(V)) for j in adjacency[i] if i<j},'graph mismatch')
 todo=[(0,frozenset(range(len(V))),frozenset())];seen=set();leaves=branches=0;max_leaf=Fraction(0);min_slack=None
 while todo:
  idx,active,chosen=todo.pop()
  require(integer(idx) and 0<=idx<len(nodes) and idx not in seen,'invalid/repeated tree node');seen.add(idx)
  node=nodes[idx]
  require(all(l1(V[i],V[j])>=4 for i,j in combinations(chosen,2)),'chosen set invalid')
  require(not (active & chosen) and all(not (adjacency[i]&active) for i in chosen),'invalid state')
  if set(node)=={'branch','include','exclude'}:
   v=node['branch'];require(integer(v) and v in active,'bad branch')
   todo.extend([(node['exclude'],active-{v},chosen),(node['include'],active-{v}-adjacency[v],chosen|{v})]);branches+=1
  elif set(node)=={'trivial'}:
   require(node['trivial'] is True and len(chosen)+len(active)<43,'bad trivial bound');leaves+=1
  else:
   require(set(node)=={'dual'},'unknown leaf')
   coverage=dict.fromkeys(active,0);total=0;used=set()
   for pair in node['dual']:
    require(type(pair) is list and len(pair)==2,'bad dual pair');j,w=pair
    require(integer(j) and 0<=j<len(C) and j not in used and integer(w) and w>=0,'bad dual term');used.add(j)
    total+=w
    for v in C[j]&active:coverage[v]+=w
   require(all(w>=D for w in coverage.values()),'invalid leaf coverage')
   bound=Fraction(total,D)+len(chosen);require(bound<43,'leaf cannot rule out target')
   max_leaf=max(max_leaf,bound);slack=43*D-total-len(chosen)*D;min_slack=slack if min_slack is None else min(min_slack,slack);leaves+=1
 require(len(seen)==len(nodes) and branches+1==leaves,'incomplete tree')
 return {'vertices':len(V),'cliques':len(C),'edges':len(edges),'nodes':len(nodes),'branches':branches,'leaves':leaves,'denominator':D,'max_leaf_bound':str(max_leaf),'min_leaf_scaled_slack':min_slack,'upper':42}

def witness(n,size):
 W=[v for v in vertices(n) if sum(i*x for i,x in enumerate(v))%5==0]
 require(len(W)==size,'wrong witness size');minimum=min(l1(x,y) for x,y in combinations(W,2));require(minimum>=4,'witness invalid')
 (OUT/f'witness_n{n}.json').write_text(json.dumps(W))
 return {'n':n,'size':len(W),'pairs_checked':math.comb(len(W),2),'minimum_l1':minimum}

if __name__=='__main__':
 r={};r['n3']=orbit_check('orbit_certificate_n3.json',3,{});r['n6']=tree_check()
 known={3:r['n3']['upper'],6:r['n6']['upper']}
 r['n10']=orbit_check('orbit_slices_n10_k6.json',10,known);r['n9']=orbit_check('orbit_slices_n9_k3.json',9,known)
 r['witnesses']=[witness(3,7),witness(6,42),witness(9,143),witness(10,201)]
 r['sha256']={f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in ['orbit_certificate_n3.json','exact_tree_n6.json.gz','orbit_slices_n10_k6.json','orbit_slices_n9_k3.json']}
 (OUT/'results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
