"""Exact length-nine audit, with metric graph and geometric slice supports."""
import gzip,json,time,hashlib
from fractions import Fraction
from itertools import combinations
import independent_check as c

def verify_tree(known):
 start=time.perf_counter()
 path=c.P/'exact_tree_n9.json.gz'
 with gzip.open(path,'rt') as f:d=json.load(f)
 c.require(type(d['n']) is int and d['n']==9 and type(d['target']) is int and d['target']==144,'wrong problem')
 D=d['denominator'];c.require(c.integer(D) and D>0,'invalid denominator')
 V=c.vertices(9);adj=[set() for _ in V]
 for i,j in combinations(range(len(V)),2):
  if c.l1(V[i],V[j])==2:adj[i].add(j);adj[j].add(i)
 constraints=[];bounds=[]
 for side in (-1,1):
  for base in c.vertices(9+side):
   supp=c.clique_support(V,base,side)
   if len(supp)>1:
    c.require(all(j in adj[i] for i,j in combinations(supp,2)),'invalid clique');constraints.append(supp);bounds.append(1)
 cliques=len(constraints)
 edges={tuple(sorted((i,j))) for s in constraints for i,j in combinations(s,2)}
 c.require(edges=={(i,j) for i in range(len(V)) for j in adj[i] if i<j},'graph mismatch')
 seen_k=set();slice_counts={}
 for pair in d['slice_bounds']:
  c.require(type(pair) is list and len(pair)==2,'invalid slice specification');k,rhs=pair
  c.require(c.integer(k) and k in known and k not in seen_k and c.integer(rhs) and rhs==known[k],'unproved slice bound');seen_k.add(k)
  bases=c.vertices(9-k);slice_counts[k]=len(bases);small=set(c.vertices(k))
  for base in bases:
   supp=frozenset(i for i,x in enumerate(V) if all(a>=b for a,b in zip(x,base)))
   translated={tuple(a-b for a,b in zip(V[i],base)) for i in supp}
   c.require(translated==small,'invalid translated simplex');constraints.append(supp);bounds.append(rhs)
 nodes=d['nodes'];todo=[(0,frozenset(range(len(V))),frozenset())];seen=set();branches=leaves=0;min_slack=None;max_bound=Fraction(0);used_slices=set()
 while todo:
  idx,active,chosen=todo.pop()
  c.require(c.integer(idx) and 0<=idx<len(nodes) and idx not in seen,'invalid/repeated node');seen.add(idx);node=nodes[idx]
  c.require(not(active&chosen) and all(not(adj[i]&active) for i in chosen),'invalid state')
  c.require(all(c.l1(V[i],V[j])>=4 for i,j in combinations(chosen,2)),'invalid chosen code')
  if set(node)=={'branch','include','exclude'}:
   v=node['branch'];c.require(c.integer(v) and v in active,'invalid branch')
   todo.extend([(node['include'],active-{v}-adj[v],chosen|{v}),(node['exclude'],active-{v},chosen)]);branches+=1
  elif set(node)=={'trivial'}:
   c.require(node['trivial'] is True and len(active)+len(chosen)<144,'invalid trivial bound');leaves+=1
  else:
   c.require(set(node)=={'dual'},'invalid leaf')
   coverage=dict.fromkeys(active,0);total=0;used=set()
   for pair in node['dual']:
    c.require(type(pair) is list and len(pair)==2,'invalid dual pair');j,w=pair
    c.require(c.integer(j) and 0<=j<len(constraints) and j not in used and c.integer(w) and w>=0,'invalid dual term');used.add(j)
    residual=bounds[j]-len(chosen&constraints[j]);c.require(residual>=0,'invalid negative residual')
    total+=w*residual
    for i in active&constraints[j]:coverage[i]+=w
    if j>=cliques and w>0:used_slices.add(j)
   c.require(all(x>=D for x in coverage.values()),'invalid coverage')
   slack=144*D-len(chosen)*D-total;c.require(slack>0,'leaf fails target')
   min_slack=slack if min_slack is None else min(min_slack,slack);max_bound=max(max_bound,Fraction(total,D)+len(chosen));leaves+=1
 c.require(len(seen)==len(nodes) and leaves==branches+1,'incomplete tree')
 return {'n':9,'vertices':len(V),'edges':len(edges),'cliques':cliques,'translated_slice_counts':slice_counts,'constraints':len(constraints),'distinct_slices_used':len(used_slices),'nodes':len(nodes),'branches':branches,'leaves':leaves,'denominator':D,'min_scaled_slack':min_slack,'max_leaf_bound':str(max_bound),'upper':143,'tree_verification_seconds':time.perf_counter()-start,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
if __name__=='__main__':
 start=time.perf_counter();r3=c.orbit_check('orbit_certificate_n3.json',3,{});r6=c.tree_check()
 r=verify_tree({3:r3['upper'],6:r6['upper']});r['witness']=c.witness(9,143);r['full_dependency_verification_seconds']=time.perf_counter()-start
 (c.OUT/'results_n9.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
