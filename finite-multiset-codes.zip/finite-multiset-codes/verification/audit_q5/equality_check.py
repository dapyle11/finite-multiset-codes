import json
from fractions import Fraction
from itertools import permutations
from collections import Counter
import independent_check as c
V=c.vertices(10);d=json.loads((c.P/'orbit_slices_n10_k6.json').read_text());cov=[Fraction(0) for v in V];regions=[]
for row in d['weights']:
 w=Fraction(row['weight']);c.require(w>0,'nonpositive displayed weight')
 for b in set(permutations(row['type'])):
  if row['kind']=='clique':s=c.clique_support(V,b,row['parameter'])
  else:s={i for i,v in enumerate(V) if all(x>=y for x,y in zip(v,b))}
  for i in s:cov[i]+=w
  if row['kind']=='simplex' and row['parameter']==6:
   regions.append({'base':b,'weight':str(w),'rhs':row['rhs'],'vertices':len(s)})
excess=Counter((tuple(sorted(V[i],reverse=True)),str(x)) for i,x in enumerate(cov) if x>1)
# The assertion below checks actual types; coverage values are output separately.
c.require({t for t,x in excess}=={(9,1,0,0,0),(3,3,3,1,0)},'unexpected excess type')
c.require(len(regions)==5 and {tuple(r['base']) for r in regions}=={tuple(4 if j==i else 0 for j in range(5)) for i in range(5)},'wrong regions')
r={'excess_types':[{'type':t,'coverage':x,'count':count} for (t,x),count in sorted(excess.items())],'length_six_regions':regions}
(c.OUT/'equality_results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
