"""Independent exact CSP enumeration, no imports from the author's scripts.
One point per floor cell; exhaustive search over every subset of target cells.
"""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from itertools import combinations
import json
from pathlib import Path
OUT=Path(__file__).parent

def dist(u,v): return max(abs(a-b) for a,b in zip(u,v))
def enumerate_target(n,d,target,all_solutions=False):
    cells={}
    for a in range(n+1):
        for b in range(n-a+1):
            v=(a,b,n-a-b)
            cells.setdefault(tuple(t//d for t in v),[]).append(v)
    # Verify rather than assume the essential partition diameter property.
    assert all(dist(u,v)<d for cell in cells.values() for u,v in combinations(cell,2))
    solutions=[]
    def visit(domains, chosen):
        if not domains:
            solutions.append(tuple(sorted(chosen)))
            return not all_solutions
        i=min(range(len(domains)),key=lambda j:len(domains[j]))
        domain=domains[i]
        rest=domains[:i]+domains[i+1:]
        for v in domain:
            reduced=[[w for w in other if dist(v,w)>=d] for other in rest]
            if all(reduced) and visit(reduced,chosen+[v]): return True
        return False
    for keys in combinations(cells,target):
        if visit([cells[key] for key in keys],[]): break
    return solutions

def claimed(n,d):
    r=n-2*d
    return [(n,0,0),(0,n,0),(0,0,n),(d+r,d,0),(d+r,0,d),(r,d+r,d-r),(r,d-r,d+r),(0,2*d-r,2*r)]
rows=[]
for d in range(1,13):
    for n in range(2*d,3*d):
        all_solutions=(3*n==8*d)
        eight=enumerate_target(n,d,8,all_solutions)
        nine=enumerate_target(n,d,9)
        assert not nine,(n,d,'nine found')
        assert bool(eight)==(3*n>=8*d),(n,d,'wrong threshold')
        if all_solutions:
            expected={tuple(sorted(tuple(v[i] for i in perm) for v in claimed(n,d))) for perm in __import__('itertools').permutations(range(3))}
            assert len(eight)==3 and set(eight)==expected
        row={'n':n,'D':d,'eight_exists':bool(eight),'nine_exists':bool(nine),'number_eight_when_equality':len(eight) if all_solutions else None}
        rows.append(row);print(row,flush=True)
        (OUT/'finite_results.json').write_text(json.dumps(rows,indent=2))
# Directly verify construction over a much wider integer range.
for d in range(1,201):
    for n in range(2*d,3*d):
        if 3*n>=8*d:
            code=claimed(n,d)
            assert len(set(code))==8 and all(min(v)>=0 and sum(v)==n for v in code)
            assert min(dist(u,v) for u,v in combinations(code,2))>=d
norm_small=[(a,b,-a-b) for a in range(-2,3) for b in range(-2,3) if abs(a+b)<=2 and (2*a+3*b)%8==0]
assert norm_small==[(0,0,0)]
base={(0,0,8),(0,8,0),(1,2,5),(2,4,2),(4,0,4),(5,2,1),(8,0,0)}
for k in range(1,21):
    actual={(a,b,8*k-a-b) for a in range(8*k+1) for b in range(8*k-a+1) if a%k==0 and b%k==0 and (2*(a//k)+3*(b//k))%8==0}
    assert actual=={tuple(k*t for t in v) for v in base}
    assert min(dist(u,v) for u,v in combinations(actual,2))==3*k
print('PASS: finite exhaustive targets, equality classification, construction through D=200, full intersections through k=20.',flush=True)
