"""Independent small-case checks, without importing the researcher's code.
The exact four-region search is exhaustive under n<2D; each region has diameter<D.
"""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from itertools import combinations
for n in range(1,16):
    V=[(a,b,n-a-b) for a in range(n+1) for b in range(n+1-a)]
    for D in range(n//2+1,n+1):
        R=[[x for x in V if x[i]>=D] for i in range(3)]
        centers=[x for x in V if max(x)<D]
        regions=R+[centers]
        adj=lambda x,y:max(abs(a-b) for a,b in zip(x,y))>=D
        assert sum(map(len,regions))==len(V)
        assert len(set().union(*map(set,regions)))==len(V)
        assert all(not adj(x,y) for region in regions for x,y in combinations(region,2))
        count=0
        for c in centers:
            choices=[[x for x in region if adj(c,x)] for region in R]
            for a in choices[0]:
                for b in choices[1]:
                    if not adj(a,b): continue
                    count+=sum(adj(a,e) and adj(b,e) for e in choices[2])
        assert (count>0)==(D<=2*n//3),(n,D,count)
        k,r=divmod(n,3)
        if r==2 and D==2*k+1:
            assert k>=1 and count==9
        if D<=2*k:
            t=(n,0,0)
            intersection=[]
            for x in V:
                delta=[x[i]-t[i] for i in range(3)]
                if all(a%k==0 for a in delta) and len({(a//k)%3 for a in delta})==1:
                    intersection.append(x)
            assert len(intersection)==4
            assert all(adj(a,b) for a,b in combinations(intersection,2))
        print(f'n={n}, D={D}: four-word codes={count}; unrestricted optimum={4 if count else 3}; claimed linear optimum={4 if D<=2*k else 3}')
print('PASS: every high-distance cone parameter 1<=n<=15; all gap cases have exactly nine four-word codes; all proposed four-word lattice intersections are exact.')
