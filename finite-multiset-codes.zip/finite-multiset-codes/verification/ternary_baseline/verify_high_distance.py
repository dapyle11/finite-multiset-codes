"""Dependency-free finite sanity checks; theorem proof is in paper/ternary_simplex.tex at the repository root."""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from itertools import combinations
import json
from pathlib import Path

def vertices(n):
    return [(x,y,n-x-y) for x in range(n+1) for y in range(n-x+1)]
def distance(x,y):
    return max(abs(a-b) for a,b in zip(x,y))
def clique_max(V,D):
    A=[set(j for j in range(i+1,len(V)) if distance(V[i],V[j])>=D) for i in range(len(V))]
    best=0
    def visit(S,k):
        nonlocal best
        best=max(best,k)
        while S:
            if k+len(S)<=best:return
            v=min(S);S.remove(v);visit(S&A[v],k+1)
    visit(set(range(len(V))),0)
    return best
rows=[]
for n in range(1,19):
    V=vertices(n)
    for D in range(n//2+1,n+1):
        actual=clique_max(V,D)
        expected=4 if 3*D<=2*n else 3
        assert actual==expected,(n,D,actual,expected)
        k,r=divmod(n,3)
        if D<=2*k:
            b=(r,0,3*k)
            C=[]
            for x in V:
                diff=[a-z for a,z in zip(x,b)]
                if all(a%k==0 for a in diff) and len(set((a//k)%3 for a in diff))==1:C.append(x)
            assert len(C)==4 and all(distance(x,y)>=D for x,y in combinations(C,2))
        rows.append(dict(n=n,D=D,optimum=actual,linear_optimum=4 if D<=2*k else 3))
for k in range(1,101):
    n=3*k+2;D=2*k+1;c=(k,k+1,k+1);B=(0,n,0);C=(0,0,n)
    p=tuple(3*x-y-z for x,y,z in zip(c,B,C))
    assert p==(3*k,1,1) and sum(p)==n and min(p)>=0 and 0<distance(c,p)<D
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2))
print(f'PASS: {len(rows)} high-distance parameter pairs through n=18; explicit lattice constructions verified; family obstruction checked for k=1..100.')
