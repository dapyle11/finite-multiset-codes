"""Fresh independent finite audit. No imported release code or four-region pruning."""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from itertools import combinations
from math import gcd
from functools import reduce
import json
from pathlib import Path

def det(a,b): return a[0]*b[1]-a[1]*b[0]
def dist(x,y): return sum(abs(a-b) for a,b in zip(x,y))//2

def closure(C,V):
    b=C[0]; gs=[(x[0]-b[0],x[1]-b[1]) for x in C[1:]]
    index=reduce(gcd,(abs(det(x,y)) for x,y in combinations(gs,2)),0)
    if index:
        return [x for x in V if all(det(g,(x[0]-b[0],x[1]-b[1]))%index==0 for g in gs)]
    v=next((g for g in gs if g!=(0,0)),None)
    if v is None:return [b]
    scale=gcd(*v); u=(v[0]//scale,v[1]//scale); j=0 if u[0] else 1
    step=reduce(gcd,(g[j]//u[j] for g in gs),0)
    out=[]
    for x in V:
        w=(x[0]-b[0],x[1]-b[1])
        if det(u,w)==0 and w[j]%(u[j]*step)==0:out.append(x)
    return out

rows=[]
for n in range(1,19):
    V=[(a,b,n-a-b) for a in range(n+1) for b in range(n+1-a)]
    for D in range(n//2+1,n+1):
        edges=[0]*len(V)
        for i,j in combinations(range(len(V)),2):
            if dist(V[i],V[j])>=D:edges[i]|=1<<j;edges[j]|=1<<i
        maximum=0; linear=0;four_count=0;closed_four=0
        def walk(C,mask):
            global maximum,linear,four_count,closed_four
            maximum=max(maximum,len(C))
            if len(C)==4:
                four_count+=1
                F=closure([V[i] for i in C],V)
                if all(dist(x,y)>=D for x,y in combinations(F,2)):
                    closed_four+=1;linear=max(linear,len(F))
            while mask:
                bit=mask&-mask;mask-=bit;i=bit.bit_length()-1
                walk(C+[i],mask&edges[i])
        walk([], (1<<len(V))-1)
        # Establish 3 linearly directly, rather than assume its lower bound.
        T=[(n,0,0),(0,n,0),(0,0,n)]
        assert set(closure(T,V))==set(T)
        linear=max(linear,3)
        assert maximum==(4 if 3*D<=2*n else 3),(n,D,maximum)
        assert linear==(4 if D<=2*(n//3) else 3),(n,D,linear)
        if n%3==2 and D==2*(n//3)+1:assert four_count==9 and closed_four==0
        rows.append(dict(n=n,D=D,optimum=maximum,linear_optimum=linear,fours=four_count,linear_fours=closed_four))
print('PASS',len(rows),'parameters through n=18; generic half-L1 cliques; full generated-lattice closure by determinant divisibility; both optima checked.')
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2))
