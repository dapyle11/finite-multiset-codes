
if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from itertools import combinations, permutations
V = [(a,b,5-a-b) for a in range(6) for b in range(6-a)]
def distance(x,y): return sum(abs(a-b) for a,b in zip(x,y)) // 2
for x,y in combinations(V,2):
    assert distance(x,y) == max(abs(a-b) for a,b in zip(x,y))
def valid(C): return all(distance(x,y)>=3 for x,y in combinations(C,2))
def canonical(C):
    return min(tuple(sorted(tuple(x[i] for i in p) for x in C)) for p in permutations(range(3)))
fours=[C for C in combinations(V,4) if valid(C)]
fives=[C for C in combinations(V,5) if valid(C)]
assert len(fours)==9 and not fives
print('Vertices:',len(V),'valid four-sets:',len(fours),'valid five-sets:',len(fives))
for rep in sorted(set(map(canonical,fours))):
    print('Orbit representative:',rep,'orbit size:',sum(canonical(C)==rep for C in fours))
for C in fours:
    c=next(x for x in C if max(x)<=2)
    i=c.index(1); j,h=[a for a in range(3) if a!=i]
    B=tuple(5 if a==j else 0 for a in range(3))
    D=tuple(5 if a==h else 0 for a in range(3))
    assert B in C and D in C
    z=tuple(3*c[a]-B[a]-D[a] for a in range(3))
    assert z in V and z!=c and distance(z,c)==2
print('Universal affine obstruction verified for all nine codes.')
