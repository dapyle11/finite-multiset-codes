"""Exact standard-library checks of the two excluded ternary boundaries."""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from itertools import combinations
from verify_high_distance import clique_max, vertices, distance
for n,D,expected in [(5,2,7),(8,4,6)]:
    V=vertices(n)
    assert clique_max(V,D)==expected
    C=[x for x in V if ((x[0]-x[1])%3==0 if n==5 else all(a%4==0 for a in x))]
    assert len(C)==expected and all(distance(x,y)>=D for x,y in combinations(C,2))
    print(f'PASS boundary: n={n}, D={D}, unrestricted=linear={expected}')
C=[(0,0,5,0),(0,1,0,4),(0,2,2,1),(0,5,0,0),(2,0,1,2),(4,1,0,0)]
assert all(sum(x)==5 for x in C)
assert min(sum(abs(a-b) for a,b in zip(x,y))//2 for x,y in combinations(C,2))==3
print('PASS: six-word q=4, n=5, D=3 counterexample to naive q+1 bound')
