"""Independent check: no imports from the proposed certificate or its helpers.
Python + SymPy; exhaustive unpruned ordered clique enumeration and exact HNF.
"""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from collections import Counter
from itertools import product, combinations, permutations
from pathlib import Path
import json
from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form

ROOT=Path(__file__).resolve().parent
cert=json.loads((ROOT.parent/'q4/certify_5_3.json').read_text())
def simplex(n):
    return sorted(x for x in product(range(n+1), repeat=4) if sum(x)==n)
def distance(x,y):
    # Independent expression for half-L1 on a constant-sum layer.
    return sum(max(a-b,0) for a,b in zip(x,y))
V=simplex(5)
assert len(V)==56
adj={i:{j for j in range(len(V)) if i!=j and distance(V[i],V[j])>=3} for i in range(len(V))}
counts=Counter(); six=[]; maximum=0
# Visit every clique exactly once, in increasing vertex order. No coloring,
# incumbent pruning, maximal-clique algorithm, or fixed-size early termination.
def visit(chosen,candidates):
    global maximum
    counts[len(chosen)]+=1
    maximum=max(maximum,len(chosen))
    if len(chosen)==6: six.append(tuple(V[i] for i in chosen))
    for pos,v in enumerate(candidates):
        visit(chosen+[v],[w for w in candidates[pos+1:] if w in adj[v]])
visit([],list(range(len(V))))
assert maximum==6 and counts[6]==288 and counts[7]==0
perms=list(permutations(range(4)))
def orbit(C):
    return {tuple(sorted(tuple(x[p[i]] for i in range(4)) for x in C)) for p in perms}
all_six=set(six); unassigned=set(six); orbit_results=[]; expected={tuple(map(tuple,r['representative'])):r for r in cert['orbit_obstructions']}
while unassigned:
    C=min(unassigned); O=orbit(C)
    assert O<=all_six and C==min(O)
    assert O<=unassigned # disjoint orbits
    unassigned-=O
    assert C in expected
    r=expected[C]
    # HNF columns span precisely the integer lattice of differences. Its inverse
    # decides membership using exact rationals, independent of gcd-of-minors.
    b=Matrix(C[0][:3]); G=Matrix.hstack(*(Matrix(x[:3])-b for x in C[1:]))
    assert G.rank()==3
    H=hermite_normal_form(G); inv=H.inv()
    closure=[x for x in V if all(t.q==1 for t in inv*(Matrix(x[:3])-b))]
    assert abs(int(H.det()))==r['generator_index']
    assert len(closure)==r['closure_size']
    x,y=map(tuple,r['forbidden_pair'])
    assert x!=y and x in closure and y in closure
    assert distance(x,y)==r['forbidden_distance']<3
    # Stronger than representative-only check: test all 288 generated lattices.
    for code in O:
        base=Matrix(code[0][:3])
        M=Matrix.hstack(*(Matrix(v[:3])-base for v in code[1:]))
        assert M.rank()==3
        HH=hermite_normal_form(M); II=HH.inv()
        CC=[v for v in V if all(t.q==1 for t in II*(Matrix(v[:3])-base))]
        assert any(distance(v,w)<3 for v,w in combinations(CC,2))
    orbit_results.append(dict(representative=C,size=len(O),index=int(abs(H.det())),closure_size=len(closure),forbidden_pair=[x,y]))
assert len(orbit_results)==14 and sum(r['size'] for r in orbit_results)==288
assert set(expected)=={tuple(map(tuple,r['representative'])) for r in orbit_results}

def full_intersection(n,H):
    inv=Matrix(H).inv()
    return [x for x in simplex(n) if all(t.q==1 for t in inv*Matrix(x[:3]))]
cases=[
(5,3,[[15,3,5],[0,1,0],[0,0,1]],[(0,0,0,5),(0,0,3,2),(0,5,0,0),(1,2,2,0),(3,1,0,1)]),
(6,4,[[4,0,2],[0,4,2],[0,0,2]],[(0,0,0,6),(0,0,4,2),(0,4,0,2),(2,2,2,0),(4,0,0,2)]),
(11,7,[[163,110,124],[0,1,0],[0,0,1]],[(0,0,0,11),(0,1,7,3),(1,7,3,0),(4,3,0,4),(7,0,4,0)])]
for n,D,H,expected_code in cases:
    actual=full_intersection(n,H)
    assert actual==expected_code
    assert min(distance(x,y) for x,y in combinations(actual,2))==D
witness=list(map(tuple,cert['unrestricted_witness']))
assert len(set(witness))==6 and set(witness)<=set(V)
assert all(distance(x,y)>=3 for x,y in combinations(witness,2))
report=dict(status='PASS',vertices=len(V),all_clique_counts=dict(sorted(counts.items())),maximum_clique=maximum,six_codes=len(six),coordinate_orbits=len(orbit_results),orbits=orbit_results,full_intersection_cases=[dict(n=n,D=D,size=5,H=H,code=C) for n,D,H,C in cases])
(ROOT/'independent_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('orbits','full_intersection_cases')},indent=2))
