#!/usr/bin/env python3
"""Dependency-free exact audit of A(8k,3k)=8, A_lin(8k,3k)=7.

Usage: python check_eight_gap.py --max-k 4 --output check_eight_gap.json
No theorem-specific pruning is used in clique enumeration. All eight-cliques
are enumerated using only graph adjacency and valid greedy-color upper bounds.
Exactly three eight-cliques precludes nine-cliques: a nine-clique would contain
nine distinct eight-cliques. Affine closure certificates explicitly exclude
every coset containing each eight-clique, irrespective of subgroup rank.
Finite checks support but do not replace the all-parameter proof.
"""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from itertools import combinations, permutations
from math import gcd
from functools import reduce
from pathlib import Path
import argparse, json

def distance(x,y):
    return sum(abs(a-b) for a,b in zip(x,y))//2

def determinant(a,b):
    return a[0]*b[1]-a[1]*b[0]

def full_rank_closure(C,V):
    b=C[0]
    generators=[(x[0]-b[0],x[1]-b[1]) for x in C[1:]]
    index=reduce(gcd,(abs(determinant(a,b)) for a,b in combinations(generators,2)),0)
    assert index>0
    return [x for x in V if all(determinant(g,(x[0]-b[0],x[1]-b[1]))%index==0 for g in generators)]

def all_eight_cliques(V,D):
    E=[0]*len(V)
    for i,j in combinations(range(len(V)),2):
        if distance(V[i],V[j])>=D:
            E[i]|=1<<j
            E[j]|=1<<i
    answer=[]
    nodes=0
    def greedy_colors(P):
        order=[];bounds=[];color=0
        while P:
            color+=1;Q=P
            while Q:
                bit=Q&-Q;v=bit.bit_length()-1
                P^=bit;Q^=bit;Q&=~E[v]
                order.append(v);bounds.append(color)
        return order,bounds
    def expand(C,P):
        nonlocal nodes
        nodes+=1
        if len(C)==8:
            answer.append(tuple(sorted(V[i] for i in C)))
            return
        order,bounds=greedy_colors(P)
        for pos in range(len(order)-1,-1,-1):
            if len(C)+bounds[pos]<8:return
            v=order[pos]
            expand(C+[v],P&E[v])
            P&=~(1<<v)
    expand([], (1<<len(V))-1)
    assert len(answer)==len(set(answer))
    return set(answer),nodes

BASE8=((8,0,0),(0,8,0),(0,0,8),(5,3,0),(5,0,3),(2,5,1),(2,1,5),(0,4,4))
BASE7=((0,0,8),(0,8,0),(1,2,5),(2,4,2),(4,0,4),(5,2,1),(8,0,0))

def main():
    p=argparse.ArgumentParser();p.add_argument('--max-k',type=int,default=4);p.add_argument('--output',default='check_eight_gap.json');args=p.parse_args()
    assert args.max_k>=1
    short=[]
    for a in range(-2,3):
        for b in range(-2,3):
            z=(a,b,-a-b)
            if z!=(0,0,0) and distance(z,(0,0,0))<=2:short.append(z)
    assert len(short)==18
    assert all((2*a+3*b)%8 for a,b,c in short)
    assert (2*1+3*2)%8==0 and distance((1,2,-3),(0,0,0))==3
    rows=[]
    for k in range(1,args.max_k+1):
        n=8*k;D=3*k
        V=[(a,b,n-a-b) for a in range(n+1) for b in range(n+1-a)]
        expected={tuple(sorted(tuple(k*x[j] for j in perm) for x in BASE8)) for perm in permutations(range(3))}
        assert len(expected)==3
        actual,nodes=all_eight_cliques(V,D)
        assert actual==expected,(k,len(actual))
        certificates=[]
        for perm in permutations(range(3)):
            C=[tuple(k*x[j] for j in perm) for x in BASE8]
            forced=tuple(C[0][j]+C[1][j]-C[3][j] for j in range(3))
            assert forced in V and forced not in C
            assert distance(forced,C[5])==k<D
            assert forced in full_rank_closure(C,V)
            certificates.append(dict(permutation=perm,forced_point=forced,nearby_word=C[5],distance=k,affine_coefficients=[1,1,0,-1,0,0,0,0]))
        C7=[tuple(k*a for a in x) for x in BASE7]
        congruence_intersection=[x for x in V if all(a%k==0 for a in x) and (2*(x[0]//k)+3*(x[1]//k))%8==0]
        assert set(congruence_intersection)==set(C7)==set(full_rank_closure(C7,V))
        assert min(distance(x,y) for x,y in combinations(C7,2))==D
        row=dict(k=k,n=n,D=D,unrestricted_optimum=8,full_coset_optimum=7,number_optimal_unrestricted_codes=3,search_nodes=nodes,eight_codes=sorted(actual),seven_code=C7,affine_obstructions=certificates)
        rows.append(row)
        Path(args.output).write_text(json.dumps(dict(method='Exact exhaustive bitset clique enumeration and integer affine-closure certificates',rows=rows),indent=2)+'\n')
        print(f'PASS k={k}: exactly three eight-cliques; no nine-clique; every eight-code has forbidden affine closure; seven-word full coset verified.',flush=True)
    print('PASS all checks. Finite verification is not an all-parameter proof.')
if __name__=='__main__':main()
