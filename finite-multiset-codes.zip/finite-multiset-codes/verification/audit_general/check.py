#!/usr/bin/env python3
"""Independent exact clique enumeration using the defining half-L1 metric."""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

import json, math, time
from pathlib import Path

def simplex(n,q):
    if q==1:
        yield (n,)
    else:
        for a in range(n+1):
            for b in simplex(n-a,q-1): yield (a,)+b

def distance(a,b): return sum(abs(x-y) for x,y in zip(a,b))//2

def enumerate_cliques(V,D,target):
    adj=[0]*len(V)
    for i,a in enumerate(V):
        for j in range(i+1,len(V)):
            if distance(a,V[j])>=D: adj[i]|=1<<j
    found=[]
    def rec(chosen,candidates):
        if len(chosen)==target:
            found.append(tuple(chosen)); return
        while candidates.bit_count()>=target-len(chosen):
            b=candidates&-candidates; candidates-=b; i=b.bit_length()-1
            rec(chosen+[i],candidates&adj[i])
    rec([], (1<<len(V))-1)
    return found

def predicted_family(q,k):
    n=q*k+q-1; out=set()
    for low in range(q):
        c=tuple(k if i==low else k+1 for i in range(q))
        fixed=[tuple(n if i==j else 0 for i in range(q)) for j in range(q) if j!=low]
        for spill in range(q):
            a=[0]*q; a[low]=n
            if spill!=low: a[low]-=1; a[spill]+=1
            out.add(tuple(sorted([c,*fixed,tuple(a)])))
    return out

start=time.time(); result={'general':[], 'family':[]}
for q,maxn in [(3,12),(4,10),(5,7),(6,5)]:
    for n in range(1,maxn+1):
        V=list(simplex(n,q))
        for D in range(1,n+1):
            s=n-D
            if 2*n<=(q+1)*s: continue
            expected=q+1 if n<=q*s else q
            # Exact upper/lower verification, with no geometric partition.
            at=enumerate_cliques(V,D,expected)
            beyond=enumerate_cliques(V,D,expected+1)
            assert at and not beyond,(q,n,D)
            result['general'].append({'q':q,'n':n,'D':D,'optimum':expected,'optimal_codes':len(at),'points':len(V)})
for q,k in [(3,1),(3,2),(3,3),(4,1),(4,2),(5,1)]:
    n=q*k+q-1; D=(q-1)*k+q-2; V=list(simplex(n,q))
    codes=enumerate_cliques(V,D,q+1)
    actual={tuple(sorted(V[i] for i in ids)) for ids in codes}
    assert actual==predicted_family(q,k),(q,k,len(actual))
    for code in actual:
        c=next(x for x in code if max(x)<=k+1)
        low=c.index(k)
        forced=[x for x in code if any(x[j]==n for j in range(q) if j!=low)]
        assert len(forced)==q-1
        p=tuple(q*c[i]-sum(x[i] for x in forced) for i in range(q))
        assert p in V and p!=c and distance(p,c)==(q-1)*k<D
    result['family'].append({'q':q,'k':k,'n':n,'D':D,'codes':len(actual),'points':len(V),'closure_obstructions':len(actual)})
result['elapsed_seconds']=time.time()-start
Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'general_cases':len(result['general']),'families':result['family'],'seconds':result['elapsed_seconds']},indent=2))
