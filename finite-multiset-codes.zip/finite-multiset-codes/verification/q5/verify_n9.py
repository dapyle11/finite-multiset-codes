"""Optional independent exact verifier for the n=9 branch certificate."""
from verify import *

def check_slice_tree(filename, known):
    with gzip.open(P / filename, 'rt') as f:
        d = json.load(f)
    validate_header(d, filename, tree=True)
    n = d['n']
    target = d['target']
    D = d['denominator']
    nodes = d['nodes']
    V, C = cliques(n)
    adj = [set() for v in V]
    for c in C:
        for v in c:
            adj[v].update(set(c) - {v})
    bounds = [1] * len(C)
    idx = {v: i for i, v in enumerate(V)}
    for k, b in d['slice_bounds']:
        require(known[k] == b, 'Certificate check failed: known[k] == b')
        for base in comps(n - k):
            C.append([idx[tuple((x + y for x, y in zip(base, v)))] for v in comps(k)])
            bounds.append(b)
    C = [set(c) for c in C]
    seen = set()
    leaves = 0

    def visit(i, active, chosen):
        nonlocal leaves
        require(type(i) is int and 0 <= i < len(nodes) and (i not in seen), 'Certificate check failed: type(i) is int and 0 <= i < len(nodes) and (i not in seen)')
        seen.add(i)
        node = nodes[i]
        if 'branch' in node:
            v = node['branch']
            require(type(v) is int and v in active, 'Certificate check failed: type(v) is int and v in active')
            visit(node['include'], active - {v} - adj[v], chosen | {v})
            visit(node['exclude'], active - {v}, chosen)
        elif 'trivial' in node:
            require(len(chosen) + len(active) < target, 'Certificate check failed: len(chosen) + len(active) < target')
            leaves += 1
        else:
            require('dual' in node, "Certificate check failed: 'dual' in node")
            cov = {v: 0 for v in active}
            total = 0
            used = set()
            for j, w in node['dual']:
                require(type(j) is int and 0 <= j < len(C) and (j not in used) and (type(w) is int) and (w >= 0), 'Certificate check failed: type(j) is int and 0 <= j < len(C) and (j not in used) and (type(w) is int) and (w >= 0)')
                used.add(j)
                residual = bounds[j] - len(C[j] & chosen)
                require(residual >= 0, 'Certificate check failed: residual >= 0')
                total += w * residual
                for v in C[j] & active:
                    cov[v] += w
            require(all((x >= D for x in cov.values())), 'Certificate check failed: all((x >= D for x in cov.values()))')
            require(total + len(chosen) * D < target * D, 'Certificate check failed: total + len(chosen) * D < target * D')
            leaves += 1
    visit(0, set(range(len(V))), set())
    require(len(seen) == len(nodes), 'Certificate check failed: len(seen) == len(nodes)')
    print(filename, ': verified', len(nodes), 'nodes and', leaves, 'leaves; upper bound', target - 1)
    return target - 1
if __name__ == '__main__':
    known = {3: check_orbits('orbit_certificate_n3.json', {})}
    known[6] = check_tree('exact_tree_n6.json.gz')
    require(check_slice_tree('exact_tree_n9.json.gz', known) == 143, "Certificate check failed: check_slice_tree('exact_tree_n9.json.gz', known) == 143")
    witness(9, 143)
    print('PASS: S5(9,1)=143, all arithmetic exact.')
