"""Independent exact-arithmetic verifier. Python standard library only."""
import json, gzip
from pathlib import Path
from fractions import Fraction
from itertools import permutations
import re

def require(condition, message='Certificate check failed'):
    if not condition:
        raise ValueError(message)

def validate_header(d, filename, tree=False):
    require(type(d.get('n')) is int and d['n'] >= 1, 'Invalid blocklength')
    m = re.search('_n(\\d+)', filename)
    require(m is not None and d['n'] == int(m.group(1)), 'Blocklength does not match certificate filename')
    if tree:
        require(type(d.get('denominator')) is int and d['denominator'] > 0, 'Invalid denominator')
        require(type(d.get('target')) is int and d['target'] >= 1, 'Invalid target')
        require(type(d.get('nodes')) is list and len(d['nodes']) > 0, 'Invalid tree')
P = Path(__file__).parent

def comps(n, q=5):
    if q == 1:
        yield (n,)
        return
    for a in range(n + 1):
        for b in comps(n - a, q - 1):
            yield ((a,) + b)

def cliques(n):
    V = list(comps(n))
    idx = {v: i for i, v in enumerate(V)}
    C = []
    for side in [-1, 1]:
        for v in comps(n + side):
            c = []
            for j in range(5):
                w = list(v)
                w[j] -= side
                if w[j] >= 0:
                    c.append(idx[tuple(w)])
            if len(c) > 1:
                C.append(c)
    return (V, C)

def check_orbits(filename, known):
    d = json.loads((P / filename).read_text())
    validate_header(d, filename)
    n = d['n']
    V = list(comps(n))
    idx = {v: i for i, v in enumerate(V)}
    cov = [Fraction(0) for v in V]
    total = Fraction(0)
    for row in d['weights']:
        kind = row.get('kind', 'clique')
        p = row.get('parameter', row.get('side'))
        a = Fraction(row['weight'])
        require(a >= 0, 'Certificate check failed: a >= 0')
        bases = set(permutations(row['type']))
        require(len(bases) == row['count'], "Certificate check failed: len(bases) == row['count']")
        rhs = 1 if kind == 'clique' else known[p]
        require(row.get('rhs', rhs) == rhs, "Certificate check failed: row.get('rhs', rhs) == rhs")
        for base in bases:
            if kind == 'clique':
                require(p in (-1, 1) and sum(base) == n + p, 'Certificate check failed: p in (-1, 1) and sum(base) == n + p')
                c = []
                for j in range(5):
                    w = list(base)
                    w[j] -= p
                    if w[j] >= 0:
                        c.append(idx[tuple(w)])
                require(all((sum((abs(x - y) for x, y in zip(V[u], V[v]))) == 2 for i, u in enumerate(c) for v in c[i + 1:])), 'Certificate check failed: all((sum((abs(x - y) for x, y in zip(V[u], V[v]))) == 2 for i, u in enumerate(c) for v in c[i + 1:]))')
            else:
                require(kind == 'simplex' and sum(base) == n - p, "Certificate check failed: kind == 'simplex' and sum(base) == n - p")
                c = [idx[tuple((x + y for x, y in zip(base, v)))] for v in comps(p)]
            for i in c:
                cov[i] += a
            total += a * rhs
    require(min(cov) >= 1, 'Certificate check failed: min(cov) >= 1')
    require(total == Fraction(d['bound']), "Certificate check failed: total == Fraction(d['bound'])")
    bound = total.numerator // total.denominator
    print(filename, ': exact weighted bound', total, '=>', bound)
    return bound

def check_tree(filename):
    with gzip.open(P / filename, 'rt') as f:
        d = json.load(f)
    validate_header(d, filename, tree=True)
    n = d['n']
    target = d['target']
    D = d['denominator']
    nodes = d['nodes']
    V, C = cliques(n)
    adj = [set() for v in V]
    for c in C:
        for v in c:
            adj[v].update(set(c) - {v})
    seen = set()
    leaves = 0

    def visit(i, active, num_chosen):
        nonlocal leaves
        require(type(i) is int and 0 <= i < len(nodes) and (i not in seen), 'Certificate check failed: type(i) is int and 0 <= i < len(nodes) and (i not in seen)')
        seen.add(i)
        node = nodes[i]
        if 'branch' in node:
            v = node['branch']
            require(type(v) is int and v in active, 'Certificate check failed: type(v) is int and v in active')
            visit(node['include'], active - {v} - adj[v], num_chosen + 1)
            visit(node['exclude'], active - {v}, num_chosen)
        elif 'trivial' in node:
            require(num_chosen + len(active) < target, 'Certificate check failed: num_chosen + len(active) < target')
            leaves += 1
        else:
            require('dual' in node, "Certificate check failed: 'dual' in node")
            cov = {v: 0 for v in active}
            total = 0
            used = set()
            for j, w in node['dual']:
                require(type(j) is int and 0 <= j < len(C) and (j not in used) and (type(w) is int) and (w >= 0), 'Certificate check failed: type(j) is int and 0 <= j < len(C) and (j not in used) and (type(w) is int) and (w >= 0)')
                used.add(j)
                total += w
                for v in C[j]:
                    if v in cov:
                        cov[v] += w
            require(all((x >= D for x in cov.values())), 'Certificate check failed: all((x >= D for x in cov.values()))')
            require(total + num_chosen * D < target * D, 'Certificate check failed: total + num_chosen * D < target * D')
            leaves += 1
    visit(0, set(range(len(V))), 0)
    require(len(seen) == len(nodes), 'Certificate check failed: len(seen) == len(nodes)')
    print(filename, ': verified', len(nodes), 'nodes and', leaves, 'leaves; upper bound', target - 1)
    return target - 1

def witness(n, size):
    W = [v for v in comps(n) if sum((i * x for i, x in enumerate(v))) % 5 == 0]
    require(len(W) == size, 'Certificate check failed: len(W) == size')
    require(all((sum((abs(x - y) for x, y in zip(u, v))) >= 4 for i, u in enumerate(W) for v in W[i + 1:])), 'Certificate check failed: all((sum((abs(x - y) for x, y in zip(u, v))) >= 4 for i, u in enumerate(W) for v in W[i + 1:]))')
    print('Syndrome witness n=', n, 'size=', size, 'verified by all pairs')
if __name__ == '__main__':
    known = {3: check_orbits('orbit_certificate_n3.json', {})}
    known[6] = check_tree('exact_tree_n6.json.gz')
    require(known == {3: 7, 6: 42}, 'Certificate check failed: known == {3: 7, 6: 42}')
    require(check_orbits('orbit_slices_n10_k6.json', known) == 201, "Certificate check failed: check_orbits('orbit_slices_n10_k6.json', known) == 201")
    witness(10, 201)
    require(check_orbits('orbit_slices_n9_k3.json', known) == 144, "Certificate check failed: check_orbits('orbit_slices_n9_k3.json', known) == 144")
    witness(9, 143)
    print('PASS: S5(10,1)=201; 143 <= S5(9,1) <= 144. All certificate arithmetic exact.')
