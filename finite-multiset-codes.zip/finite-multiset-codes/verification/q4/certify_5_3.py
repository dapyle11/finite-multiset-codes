"""Dependency-free exhaustive certificate: q=4,n=5,D=3 gives 6 versus 5."""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from itertools import combinations, permutations
from math import gcd
from functools import reduce
from pathlib import Path
import json
from probe import vertices,dist,clique

def det(a,b,c):
 return a[0]*(b[1]*c[2]-b[2]*c[1])-b[0]*(a[1]*c[2]-a[2]*c[1])+c[0]*(a[1]*b[2]-a[2]*b[1])
def index(G):return reduce(gcd,(abs(det(*t)) for t in combinations(G,3)),0)
def canon(C):return min(tuple(sorted(tuple(v[i] for i in p) for v in C)) for p in permutations(range(4)))
def all_k(V,D,k):
 A=[set(j for j in range(i+1,len(V)) if dist(V[i],V[j])>=D) for i in range(len(V))]
 def walk(C,S):
  if len(C)==k:yield tuple(V[i] for i in C);return
  while len(C)+len(S)>=k:
   v=min(S);S.remove(v);yield from walk(C+[v],S&A[v])
 yield from walk([],set(range(len(V))))
V=vertices(5)
C,nodes=clique(V,3);assert len(C)==6
allcodes=list(all_k(V,3,6));assert len(allcodes)==288
reps=sorted(set(map(canon,allcodes)));assert len(reps)==14
cert=[]
for C in reps:
 b=C[0];G=[tuple(x[i]-b[i] for i in range(3)) for x in C[1:]];g=index(G)
 assert g>0 # Full rank, so determinant-index test is complete.
 closure=[x for x in V if index(G+[tuple(x[i]-b[i] for i in range(3))])==g]
 pair=next((x,y) for x,y in combinations(closure,2) if dist(x,y)<3)
 cert.append(dict(representative=C,generator_index=g,closure_size=len(closure),forbidden_pair=pair,forbidden_distance=dist(*pair)))
# Explicit full-lattice five-code. H has determinant 15 and columns as below.
H=[(15,0,0),(3,1,0),(5,0,1)]
L=[x for x in V if index(H+[x[:3]])==15]
assert L==[(0,0,0,5),(0,0,3,2),(0,5,0,0),(1,2,2,0),(3,1,0,1)]
assert all(dist(x,y)>=3 for x,y in combinations(L,2))
result=dict(q=4,n=5,D=3,unrestricted_optimum=6,linear_optimum=5,number_six_codes=288,number_orbits=14,unrestricted_witness=C,linear_witness=L,linear_H_columns=H,orbit_obstructions=cert)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print('PASS: unrestricted optimum 6; all 288 six-codes / 14 orbits fail full lattice closure; explicit full lattice optimum 5.')
