"""Exact full-intersection checks for two counterexamples to a lattice threshold."""

if not __debug__:
    raise RuntimeError("Verification requires Python without -O: assertions must remain enabled.")

from itertools import combinations
from probe import vertices,dist
CASES=[
 (6,4,4,0,2,[(0,0,0,6),(0,0,4,2),(0,4,0,2),(2,2,2,0),(4,0,0,2)]),
 (11,7,163,110,124,[(0,0,0,11),(0,1,7,3),(1,7,3,0),(4,3,0,4),(7,0,4,0)])]
# n6 H columns are (4,0,0),(0,4,0),(2,2,2); n11 H columns
# are (163,0,0),(110,1,0),(124,0,1). Bases are (0,0,0,n).
for n,D,mod,a,b,expected in CASES:
 if n==6:
  C=[x for x in vertices(n) if x[2]%2==0 and (x[0]-x[2])%4==0 and (x[1]-x[2])%4==0]
 else:
  C=[x for x in vertices(n) if (x[0]-a*x[1]-b*x[2])%mod==0]
 assert C==expected
 assert min(dist(x,y) for x,y in combinations(C,2))==D
 assert D>3*(n//4)
 print(f'PASS q4 n={n} D={D}: full lattice intersection exactly five words; D>3 floor(n/4).')
