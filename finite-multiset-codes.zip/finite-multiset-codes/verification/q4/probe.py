from itertools import combinations
import json,time
from pathlib import Path

def vertices(n):return [(a,b,c,n-a-b-c) for a in range(n+1) for b in range(n-a+1) for c in range(n-a-b+1)]
def dist(x,y):return sum(abs(a-b) for a,b in zip(x,y))//2

def clique(V,D):
 N=len(V); A=[0]*N
 for i,j in combinations(range(N),2):
  if dist(V[i],V[j])>=D:A[i]|=1<<j;A[j]|=1<<i
 best=[];nodes=0
 def expand(C,P):
  nonlocal best,nodes
  nodes+=1
  # greedy color compatibility graph: valid upper bound
  order=[];bounds=[];rem=P;color=0
  while rem:
   color+=1;Q=rem
   while Q:
    bit=Q&-Q;v=bit.bit_length()-1;rem^=bit;Q^=bit;Q&=~A[v];order.append(v);bounds.append(color)
  for v,b in zip(reversed(order),reversed(bounds)):
   if len(C)+b<=len(best):return
   new=C+[v];R=P&A[v]
   if not R:
    if len(new)>len(best):best=new
   else:expand(new,R)
   P&=~(1<<v)
 expand([], (1<<N)-1)
 return [V[i] for i in best],nodes
if __name__=='__main__':
 rows=[]
 for n in range(1,17):
  for D in range(n//2+1,n+1):
   t=time.time();C,nodes=clique(vertices(n),D);r=dict(n=n,D=D,size=len(C),code=C,nodes=nodes,seconds=time.time()-t);rows.append(r);print(n,D,len(C),nodes,round(r['seconds'],2),C,flush=True);Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2))
