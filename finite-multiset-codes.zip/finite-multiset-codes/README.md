# Finite Multiset Codes and Affine Lattice Restrictions

This is one integrated research note and its reproducibility bundle, dated 18 October 2026. Read `paper/finite_multiset_codes.pdf`; edit `paper/finite_multiset_codes.tex`. No third-party paper PDFs are redistributed. The earlier ternary note was retained separately as a private baseline backup, not included as a competing paper here.

## Results

- Exact capped-code reduction and unrestricted high-distance cone for every alphabet size.
- For q >= 3, s >= 2, n = qs - 1, D = (q - 1)s - 1: unrestricted optimum q + 1, full affine-subgroup-coset optimum q, with all q^2 extremizers classified.
- Complete original three-coordinate high-distance classification.
- Sharp eight-word threshold in 2D <= n < 3D and the infinite 8-versus-7 full-coset gap at n = 8k, D = 3k.
- Exact four-coordinate values A4(5,3) = 6 and full-coset optimum 5, with 288 extremizers in 14 orbits.
- Exact quinary single-deletion values S5(9,1) = 143 and S5(10,1) = 201, certified by integer branch trees and rational covers. These verify two finite cases, not the general conjecture.

All metrics in the paper are half-L1 unless explicitly called ordinary L1. Full coset means the entire intersection, with no pruning. Every subgroup rank is permitted.

## Requirements

Use Python 3.10 or later in normal (non-optimized) mode. Most checks use only the standard library. The additional independent four-coordinate HNF checker requires SymPy (`python -m pip install sympy`). No SciPy, MILP solver, or floating-point optimum is required for verification. Assertions in legacy checkers are protected by an explicit startup error under Python `-O`; the strict quinary independent checkers retain validation under optimization.

Run the following from this bundle's root. Scripts may regenerate their adjacent result JSON files. Preserve the distributed bundle or verify a copy when comparing checksums.

## Primary reproducibility commands

```sh
python verification/ternary_baseline/fresh_determinant_check.py
python verification/audit_general/check.py
python verification/ternary/check_eight_gap.py --max-k 4 --output eight_quick_results.json
python verification/q4/certify_5_3.py
python verification/q4/verify_linear_counterexamples.py
python verification/q5/verify.py
python verification/q5/verify_n9.py
```

Expected conclusions:

1. Ternary baseline: all 90 high-distance pairs through n = 18; 17,391 four-sets, 324 valid full generated intersections.
2. General cone: 87 parameter pairs across q = 3,4,5,6 (see the JSON for exact count/ranges), plus six separation-family cases, with q^2 extremizers and all affine obstructions verified.
3. Eight-word family: exactly three eight-codes at every k = 1,...,4; exact seven-word lattice construction and obstruction. The distributed longer result records k = 1,...,8. Regenerate that longer run by changing `--max-k 4` to `--max-k 8`; it can take appreciably longer.
4. Four-coordinate certificate prints `PASS: unrestricted optimum 6; all 288 six-codes / 14 orbits fail full lattice closure; explicit full lattice optimum 5.` Boundary checker verifies the full five-word codes at (6,4) and (11,7).
5. Quinary `verify.py` verifies n = 3 and 6 prerequisites, the exact n = 10 value, and a weaker n = 9 bound of 144. Run `verify_n9.py` as well: it verifies the additional 221-node tree and prints `PASS: S5(9,1)=143, all arithmetic exact.` The old weaker bound is retained only as optional supporting evidence.

## Additional independent checks

```sh
python verification/audit_eight/independent_check.py
python verification/audit_q4/independent_check.py
python verification/audit_q5/independent_check.py
python verification/audit_q5/independent_check_n9.py
python verification/audit_q5/equality_check.py
python verification/audit_q5/mutation_tests.py
```

The eight-word audit checks all 78 band cases with 1 <= D <= 12, including nonexistence of nine-codes and the sharp eight-code threshold. The independent q4 checker uses exact HNF and requires SymPy. The independent quinary checks reconstruct the metric graphs and geometric constraint supports without importing the discovery programs. They verify 1,637 length-six tree nodes, 221 length-nine nodes, and all 1,001 length-ten coverage inequalities. Equality checks establish the forbidden vertex orbits and five tight 42-word translates. Mutation tests intentionally corrupt certificates and must reject them.

## Building the paper

With a normal TeX Live installation:

```sh
cd paper
pdflatex -interaction=nonstopmode -halt-on-error finite_multiset_codes.tex
pdflatex -interaction=nonstopmode -halt-on-error finite_multiset_codes.tex
```

The source uses standard article, geometry, fontenc, lmodern, amsmath, amssymb, amsthm, booktabs, hyperref, and microtype packages. The PDF was rendered and every page visually inspected. SHA-256 digests are in `MANIFEST.sha256`; run `sha256sum -c MANIFEST.sha256` before regenerating results.

## Verification, scope, and attribution

Daniel A. Pyle initiated the project and requested the research. Lyra, powered by OpenAI, performed the scientific analysis, proof development, literature review, programming, computations, AI checks, and drafting. No specialized human mathematical verification or peer review is claimed, and OpenAI did not sponsor or endorse the work.

The heavy-coordinate decomposition extends the cap-one method credited in the paper. Generality, simplification, exact extremizer classification, boundary counterexamples, and separate checks were pursued before this release. Remaining general-alphabet full-coset classifications and the all-length quinary conjecture are not solved here. The closely related Chen–He–Ge 2024 paper remains unexamined in full; no exhaustive novelty or priority clearance is claimed. The package is prepared for review, not represented as published or accepted.

No license has been selected; see `LICENSE_STATUS.md`.
